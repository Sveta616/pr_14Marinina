﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace zad1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(numericUpDown1.Value);
            Stack<int> num = new Stack<int>();
            listBox1.Items.Add($"Размерность стека={n}");
            listBox1.Items.Add($"Верхний элемент стека={n}");
            for (int i = 1; i <= n; i++)
            {
                num.Push(i);
            }
            listBox1.Items.Add($"Размерность стека={num.Count}");
            listBox1.Items.Add($"Содержимое стека:{string.Join(" ", num)}");

            listBox1.Items.Add($"Новая размерность стека={num.Count}");

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool a = true;
            int c = 0, b = 0;
            Stack<char> stack = new Stack<char>();
            try
            {
                if (textBox1.Text != "")
                {
                    string s = textBox1.Text;
                    for (int i = 0; i < s.Length; i++)
                    {
                        stack.Push(s[i]);
                        char k = s[i];
                        if (stack.Peek() != '0' && stack.Peek() != '1' && stack.Peek() != '2' && stack.Peek() != '3' &&
                            stack.Peek() != '4' && stack.Peek() != '5' && stack.Peek() != '6' && stack.Peek() != '7' &&
                            stack.Peek() != '8' && stack.Peek() != '9' && stack.Peek() != '/' && stack.Peek() != '*' &&
                            stack.Peek() != '-' && stack.Peek() != '+' && stack.Peek() != '.' && stack.Peek() != ')' &&
                            stack.Peek() != '(') ;
                        a = false;
                        if (stack.Peek() == ')') c++;
                        if (stack.Peek() == '(') b++;
                    }
                    if (a == true && c == b)
                    {
                        listBox2.Items.Add("скобки сбалансированы");
                        listBox2.Items.Add(s);
                        StreamWriter sw = File.CreateText("new.txt");
                        sw.WriteLine(s);
                        sw.Close();
                    }
                    else if (c > b)
                    {
                        listBox2.Items.Add($"возможно лишняя ) скобка на позиции: {s.IndexOf("(")}");
                    }
                    else if (c < b)
                    {
                        listBox2.Items.Add($"возможно лишняя ( скобка на позиции: {s.IndexOf(")")}");
                    }
                }
            }
            catch (FormatException) { MessageBox.Show("Ошибка"); }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Queue<int> a = new Queue<int>();
            a.Clear();
           
                int n = Convert.ToInt32(numericUpDown2.Value);
                for (int i = 1; i <= n; i++)
                {
                    a.Enqueue(i);
                }


            if (a.Count > 0)
            {
                listBox3.Items.Add($"n={numericUpDown2.Text}");
                listBox3.Items.Add($"Размерность очереди: {a.Count}");
                listBox3.Items.Add($"Верхний элемент сочереди:{string.Join(" ", a)}");
                a.Clear();
                listBox3.Items.Add($"Новая размерность очереди:{a.Count}");
            }
            else MessageBox.Show("Очередь пустая");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Queue<Person> people = new Queue<Person>();
            string file = "file.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден");
            }
            else
            {
                string[] s = File.ReadAllLines(file);

                Person p1 = new Person("", "", "", 0, 0.0);

                foreach (string v in s)
                {
                    string[] peopl = v.Split(' ');
                    string surname = peopl[0];
                    p1.Set_surname(surname);
                    string name = peopl[1];
                    p1.Set_name(name);
                    string ot = peopl[2];
                    p1.Set_ot(ot);
                    int age = Convert.ToInt32(peopl[3]);
                    p1.Set_age(age);
                    double ves = Convert.ToDouble(peopl[4]);
                    p1.Set_ves(ves);
                    listBox4.Items.Add($"{p1.Get_surname()} {p1.Get_name()} {p1.Get_ot()}, Возраст: {p1.Get_age()} лет, Вес:{p1.Get_ves()} кг");
                    people.Enqueue(new Person(surname, name, ot, age, ves));
                }
                var yung = from p in people
                           where Convert.ToInt32(p.Get_age()) < 40
                           select p;

                foreach (var a in yung)
                {
                    listBox5.Items.Add($"{a.Get_surname()} {a.Get_name()} {a.Get_ot()}, Возраст: {a.Get_age()} лет, Вес: {a.Get_ves()} кг");
                }
            }
        
    }
    }
    }
    

