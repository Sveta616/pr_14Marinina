﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace zad1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(numericUpDown1.Value);
            Stack<int> num = new Stack<int>();
            listBox1.Items.Add($"Размерность стека={n}");
            listBox1.Items.Add($"Верхний элемент стека={n}");
            for (int i = 1; i <= n; i++)
            {
                num.Push(i);
            }
            listBox1.Items.Add($"Размерность стека={num.Count}");
            listBox1.Items.Add($"Содержимое стека:{string.Join(" ", num)}");

            listBox1.Items.Add($"Новая размерность стека={num.Count}");

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
      
            bool a = true;
            int c = 0, b = 0;
            StreamWriter sw = File.CreateText("new.txt");
            Stack<char> stack = new Stack<char>();
            try
            {
                if (textBox1.Text != "")
                {
                    string s = textBox1.Text;
                    for (int i = 0; i < s.Length; i++)
                    {
                        stack.Push(s[i]);
                        char k = s[i];
                        if (char.IsDigit(s[i]))
                            a = false;
                        if (stack.Peek() == ')') c++;
                        if (stack.Peek() == '(') b++;
                    }
                    if (a == true && c == b)
                    {
                        listBox2.Items.Add("скобки сбалансированы");
                        listBox2.Items.Add(s);
                        sw.WriteLine(s);
                        sw.Close();
                    }
                    else if (c > b)
                    {
                        listBox2.Items.Add($"возможно лишняя ) скобка на позиции: {textBox1.Text.IndexOf('(')}");
                        StreamWriter sw2 = new StreamWriter("new1.txt");
                        sw2.WriteLine(')' + textBox1.Text);
                        sw2.Close();
                    }
                    else if (c < b)
                    {
                        listBox2.Items.Add($"возможно лишняя ( скобка на позиции: {textBox1.Text.IndexOf(')')}");
                        StreamWriter sw3 = new StreamWriter("new1.txt");
                        sw3.WriteLine(textBox1.Text + ')');
                        sw3.Close();
                    }
                    else MessageBox.Show("Вы не ввели выражение");
                }

            }
            catch (FormatException) { MessageBox.Show("Ошибка"); }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Queue<int> a = new Queue<int>();
            a.Clear();

            int n = Convert.ToInt32(numericUpDown2.Value);
            for (int i = 1; i <= n; i++)
            {
                a.Enqueue(i);
            }


            if (a.Count > 0)
            {
                listBox3.Items.Add($"n={numericUpDown2.Text}");
                listBox3.Items.Add($"Размерность очереди: {a.Count}");
                listBox3.Items.Add($"Верхний элемент сочереди:{string.Join(" ", a)}");
                a.Clear();
                listBox3.Items.Add($"Новая размерность очереди:{a.Count}");
            }
            else MessageBox.Show("Очередь пустая");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Queue<Person> people = new Queue<Person>();
            string file = "file.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден");
            }
            else
            {
                string[] s = File.ReadAllLines(file);

                Person p1 = new Person("", "", "", 0, 0.0);

                foreach (string v in s)
                {
                    string[] peopl = v.Split(' ');
                    string surname = peopl[0];
                    p1.Set_surname(surname);
                    string name = peopl[1];
                    p1.Set_name(name);
                    string ot = peopl[2];
                    p1.Set_ot(ot);
                    int age = Convert.ToInt32(peopl[3]);
                    p1.Set_age(age);
                    double ves = Convert.ToDouble(peopl[4]);
                    p1.Set_ves(ves);
                    listBox4.Items.Add($"{p1.Get_surname()} {p1.Get_name()} {p1.Get_ot()}, Возраст: {p1.Get_age()} лет, Вес:{p1.Get_ves()} кг");
                    people.Enqueue(new Person(surname, name, ot, age, ves));
                }
                var yung = from p in people
                           where Convert.ToInt32(p.Get_age()) < 40
                           select p;

                foreach (var a in yung)
                {
                    listBox5.Items.Add($"{a.Get_surname()} {a.Get_name()} {a.Get_ot()}, Возраст: {a.Get_age()} лет, Вес: {a.Get_ves()} кг");
                }
            }

        }

 


        private void button6_Click(object sender, EventArgs e)
        {
            Queue<Person> people1 = new Queue<Person>();
            string file1 = "file1.txt";
            string file2 = "file2.txt";
            if (!File.Exists(file1) && !File.Exists(file2))
            {
                MessageBox.Show("файл не найден");
            }
            else
            {
                string[] a1 = File.ReadAllLines(file1);
                Person p1 = new Person("", "", "");
                foreach (string b in a1)
                {
                    string[] p6 = b.Split(' ');
                    string name = p6[0];
                    p1.Set_name(name);
                    string surname = p6[1];
                    p1.Set_surname(surname);
                    string ot = p6[2];
                    p1.Set_ot(ot);
                    listBox9.Items.Add($"{p1.Get_name()} {p1.Get_surname()} {p1.Get_ot()}");
                    people1.Enqueue(new Person(name, surname, ot));
                    listBox8.Items.Add($"{p1.Get_name()} {p1.Get_surname()} {p1.Get_ot()}");
                    listBox8.Sorted = (true);

                }
                string[] a2 = File.ReadAllLines(file2);
                Person p2 = new Person(0, 0.0);
                foreach (string b1 in a2)
                {
                    string[] p3 = b1.Split(' ');
                    int age = Convert.ToInt32(p3[0]);
                    p2.Set_age(age);
                    double ves = Convert.ToDouble(p3[1]);
                    p2.Set_ves(ves);
                    listBox9.Items.Add($"Возраст: {p2.Get_age()} Вес: {p2.Get_ves()}");
                    people1.Enqueue(new Person(age, ves));
                    listBox8.Items.Add($"{p2.Get_age()} {p2.Get_ves()}");
                    listBox9.Sorted = (true);
                    people1.Enqueue(new Person(age, ves));
                }

            }
        }
    }
    }
    
    
    

