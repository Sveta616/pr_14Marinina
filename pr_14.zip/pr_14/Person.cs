﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad1
{
    class Person
    {
        private string surname;
        private string name;
        private string ot;
        private int age;
        private double ves;

        public Person(string surname, string name, string ot, int age, double ves)
        {
            this.surname = surname;
            this.name = name;
            this.ot = ot;
            this.age = age;
            this.ves = ves;
        }
        public void Set_surname(string surname)
        {
            this.surname = surname;
        }
        public string Get_surname()
        {
            return this.surname;
        }
        public void Set_name(string name)
        {
            this.name = name;
        }
        public string Get_name()
        {
            return this.name;
        }
        public void Set_ot(string ot)
        {
            this.ot = ot;
        }
        public string Get_ot()
        {
            return this.ot;
        }
        public void Set_age(int age)
        {
            this.age = age;
        }
        public int Get_age()
        {
            return this.age;
        }
        public void Set_ves(double ves)
        {
            this.ves = ves;
        }
        public double Get_ves()
        {
            return this.ves;
        }
    }
}
